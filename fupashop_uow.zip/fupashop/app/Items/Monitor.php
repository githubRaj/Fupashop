<?php

namespace App\Items;

class Monitor
{
    //protected $table = 'monitors';
}
