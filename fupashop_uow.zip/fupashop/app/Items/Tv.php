<?php

namespace App\Items;



class Tv
{
    /*protected $fillable = [
        'modelNumber', 'brandName', 'price', 'weight','displaySize', 'dimensions', 'screenSize','ramSize','cpucores','hddSize','batteryInformation','operatingSystem','cameraInformation',
    ];*/
}
