<?php

namespace App\Items;

class Laptop
{
    //protected $table = 'laptops';
}
