<?php

namespace App\Items;

//use Illuminate\Database\Eloquent\Model;

class Desktop
{
    //protected $table = 'desktops';
    
}
