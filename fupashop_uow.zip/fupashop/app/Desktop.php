<?php

namespace App\Items;

use Illuminate\Database\Eloquent\Model;

class Desktop extends Model
{
    protected $table = 'desktops';
}
